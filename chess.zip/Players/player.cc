#include "player.h"
using namespace std;

/*string Player::getMove() const {
    return "";
}*/
