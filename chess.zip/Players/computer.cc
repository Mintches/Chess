#include "computer.h"
using namespace std;

/*string Computer::getMove() const {
    
    return "";
}*/
