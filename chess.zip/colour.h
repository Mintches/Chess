#ifndef COLOUR_H
#define COLOUR_H

enum class Colour {
    WHITE, BLACK, BLUE, LIGHT_BLUE
};

#endif
